﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace elevi
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdauga_Click(object sender, EventArgs e)
        {
            lstElevi.Items.Add(txtElev.Text.Trim());
            txtElev.Text = "";
            txtElev.Focus();
            lstNote.Items.Add(txtNota.Text.Trim());
            txtNota.Text = "";
            txtNota.Focus();
            
            if(txtElev.Text.Trim()=="")
            {
                return;
            }
            {
                lstElevi.Items.Add(txtElev.Text.Trim());

            }
        }

        private void btnSterge_Click(object sender, EventArgs e)
        {
            if(lstElevi.SelectedIndex!=-1)
            {
                lstElevi.Items.RemoveAt(lstElevi.SelectedIndex);
            }
            else
            {
                return;
            }
            if (lstNote.SelectedIndex != -1)
            {
                lstNote.Items.RemoveAt(lstNote.SelectedIndex);
            }
            else
            {
                return;

            }
          
        }

        private void lstElevi_Click(object sender, EventArgs e)
        {
            lstNote.SelectedIndex = lstElevi.SelectedIndex;
        }

        private void lstNote_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstElevi.SelectedIndex = lstNote.SelectedIndex;
        }

        private void btnGolire_Click(object sender, EventArgs e)
        {
            lstElevi.Items.Clear();
            lstNote.Items.Clear();
        }

        private void lstElevi_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstNote.SelectedIndex = lstElevi.SelectedIndex;
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            lst7.Items.Clear();
           for(int i=0;i< lstElevi.Items.Count; i++)
            {
                if (Convert.ToInt32(lstNote.Items[i].ToString())>=7)
                {
                    lst7.Items.Add(lstElevi.Items[i].ToString() + "," + lstNote.Items[i].ToString());
                }
            }
        }
    }
}
