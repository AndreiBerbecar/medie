﻿namespace elevi
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstElevi = new System.Windows.Forms.ListBox();
            this.txtElev = new System.Windows.Forms.TextBox();
            this.btnAdauga = new System.Windows.Forms.Button();
            this.btnSterge = new System.Windows.Forms.Button();
            this.lstNote = new System.Windows.Forms.ListBox();
            this.txtNota = new System.Windows.Forms.TextBox();
            this.btnGolire = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.lst7 = new System.Windows.Forms.ListBox();
            this.lblElevi = new System.Windows.Forms.Label();
            this.lblNota = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lstElevi
            // 
            this.lstElevi.BackColor = System.Drawing.Color.Linen;
            this.lstElevi.FormattingEnabled = true;
            this.lstElevi.Location = new System.Drawing.Point(240, 115);
            this.lstElevi.Name = "lstElevi";
            this.lstElevi.Size = new System.Drawing.Size(162, 212);
            this.lstElevi.TabIndex = 0;
            this.lstElevi.Click += new System.EventHandler(this.lstElevi_Click);
            this.lstElevi.SelectedIndexChanged += new System.EventHandler(this.lstElevi_SelectedIndexChanged);
            // 
            // txtElev
            // 
            this.txtElev.BackColor = System.Drawing.Color.Linen;
            this.txtElev.Location = new System.Drawing.Point(269, 73);
            this.txtElev.Name = "txtElev";
            this.txtElev.Size = new System.Drawing.Size(100, 20);
            this.txtElev.TabIndex = 1;
            // 
            // btnAdauga
            // 
            this.btnAdauga.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnAdauga.Location = new System.Drawing.Point(690, 94);
            this.btnAdauga.Name = "btnAdauga";
            this.btnAdauga.Size = new System.Drawing.Size(65, 28);
            this.btnAdauga.TabIndex = 2;
            this.btnAdauga.Text = "ADAUGA";
            this.btnAdauga.UseVisualStyleBackColor = false;
            this.btnAdauga.Click += new System.EventHandler(this.btnAdauga_Click);
            // 
            // btnSterge
            // 
            this.btnSterge.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnSterge.Location = new System.Drawing.Point(690, 142);
            this.btnSterge.Name = "btnSterge";
            this.btnSterge.Size = new System.Drawing.Size(65, 27);
            this.btnSterge.TabIndex = 3;
            this.btnSterge.Text = "STERGE";
            this.btnSterge.UseVisualStyleBackColor = false;
            this.btnSterge.Click += new System.EventHandler(this.btnSterge_Click);
            // 
            // lstNote
            // 
            this.lstNote.BackColor = System.Drawing.Color.Linen;
            this.lstNote.FormattingEnabled = true;
            this.lstNote.Location = new System.Drawing.Point(462, 115);
            this.lstNote.Name = "lstNote";
            this.lstNote.Size = new System.Drawing.Size(162, 212);
            this.lstNote.TabIndex = 4;
            this.lstNote.SelectedIndexChanged += new System.EventHandler(this.lstNote_SelectedIndexChanged);
            // 
            // txtNota
            // 
            this.txtNota.BackColor = System.Drawing.Color.Linen;
            this.txtNota.Location = new System.Drawing.Point(494, 73);
            this.txtNota.Name = "txtNota";
            this.txtNota.Size = new System.Drawing.Size(100, 20);
            this.txtNota.TabIndex = 5;
            // 
            // btnGolire
            // 
            this.btnGolire.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btnGolire.Location = new System.Drawing.Point(690, 198);
            this.btnGolire.Name = "btnGolire";
            this.btnGolire.Size = new System.Drawing.Size(65, 27);
            this.btnGolire.TabIndex = 6;
            this.btnGolire.Text = "GOLIRE";
            this.btnGolire.UseVisualStyleBackColor = false;
            this.btnGolire.Click += new System.EventHandler(this.btnGolire_Click);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.btn7.Location = new System.Drawing.Point(690, 254);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(65, 27);
            this.btn7.TabIndex = 7;
            this.btn7.Text = "Nota>7";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // lst7
            // 
            this.lst7.BackColor = System.Drawing.Color.Linen;
            this.lst7.FormattingEnabled = true;
            this.lst7.Location = new System.Drawing.Point(23, 115);
            this.lst7.Name = "lst7";
            this.lst7.Size = new System.Drawing.Size(162, 212);
            this.lst7.TabIndex = 8;
            // 
            // lblElevi
            // 
            this.lblElevi.AutoSize = true;
            this.lblElevi.BackColor = System.Drawing.Color.Transparent;
            this.lblElevi.Location = new System.Drawing.Point(301, 44);
            this.lblElevi.Name = "lblElevi";
            this.lblElevi.Size = new System.Drawing.Size(37, 13);
            this.lblElevi.TabIndex = 9;
            this.lblElevi.Text = "ELEVI";
            // 
            // lblNota
            // 
            this.lblNota.AutoSize = true;
            this.lblNota.BackColor = System.Drawing.Color.Transparent;
            this.lblNota.Location = new System.Drawing.Point(524, 44);
            this.lblNota.Name = "lblNota";
            this.lblNota.Size = new System.Drawing.Size(37, 13);
            this.lblNota.TabIndex = 10;
            this.lblNota.Text = "NOTE";
            // 
            // Form1
            // 
            this.AcceptButton = this.btnAdauga;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightSeaGreen;
            this.ClientSize = new System.Drawing.Size(783, 504);
            this.Controls.Add(this.lblNota);
            this.Controls.Add(this.lblElevi);
            this.Controls.Add(this.lst7);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btnGolire);
            this.Controls.Add(this.txtNota);
            this.Controls.Add(this.lstNote);
            this.Controls.Add(this.btnSterge);
            this.Controls.Add(this.btnAdauga);
            this.Controls.Add(this.txtElev);
            this.Controls.Add(this.lstElevi);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstElevi;
        private System.Windows.Forms.TextBox txtElev;
        private System.Windows.Forms.Button btnAdauga;
        private System.Windows.Forms.Button btnSterge;
        private System.Windows.Forms.ListBox lstNote;
        private System.Windows.Forms.TextBox txtNota;
        private System.Windows.Forms.Button btnGolire;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.ListBox lst7;
        private System.Windows.Forms.Label lblElevi;
        private System.Windows.Forms.Label lblNota;
    }
}

